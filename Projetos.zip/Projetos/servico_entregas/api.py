from flask import Flask, request, jsonify
from .logistica_gateway import LogisticaGateway, ServiceUnavailableError
from .entrega_service import EntregaService, EntregaRepository

app = Flask(__name__)
PORT_ENTREGAS = 5000 # Porta Padrão do Serviço Entregas

# ----------------------------------------------------
# 1. INJEÇÃO DE DEPENDÊNCIA (Instanciação dos Componentes)
# ----------------------------------------------------
entrega_repository = EntregaRepository()
logistica_gateway = LogisticaGateway()
entrega_service = EntregaService(logistica_gateway, entrega_repository)

# ----------------------------------------------------
# 2. ENDPOINTS (API REST)
# ----------------------------------------------------

@app.route('/entregas/frete', methods=['POST'])
def solicitar_frete_endpoint():
    """Endpoint para calcular frete."""
    dados_frete = request.get_json()

    if not dados_frete:
        return jsonify({"mensagem": "Dados de frete ausentes."}), 400
        
    resultado = entrega_service.solicitar_frete(dados_frete)

    if resultado['status'] == 'ERRO':
        # Mapeamento do ERRO do Service para o Status HTTP (Critério de Rastreamento)
        if 'CEP' in resultado['mensagem'] or 'formato' in resultado['mensagem']:
            status_code = 400
        elif 'não encontrado' in resultado['mensagem']:
            status_code = 404
        else:
            status_code = 500
            
        return jsonify({"mensagem": resultado['mensagem']}), status_code

    # SUCESSO
    return jsonify(resultado['detalhes']), 200

@app.route('/entregas/rastreio/<codigo>', methods=['GET'])
def consultar_rastreio_endpoint(codigo):
    """Endpoint para rastrear encomenda."""
    
    resultado = entrega_service.consultar_rastreio(codigo)
    
    if resultado['status'] == 'SUCESSO':
        return jsonify(resultado['detalhes']), 200
    
    if resultado['status'] == 'ERRO':
        # Mapeamento do ERRO do Service para o Status HTTP
        status_code = 404 if 'não encontrado' in resultado['mensagem'] else 400
        return jsonify({"mensagem": resultado['mensagem']}), status_code
        
    if resultado['status'] == 'FALHA_LOGISTICA':
        # 503 quando o retry esgota as tentativas (Tolerância a Falhas)
        return jsonify({"mensagem": resultado['mensagem']}), 503

if __name__ == '__main__':
    print(f"ServiçoEntregas rodando em http://localhost:{PORT_ENTREGAS}")
    app.run(port=PORT_ENTREGAS, debug=True, use_reloader=False) # <--- CORRIGIDO
