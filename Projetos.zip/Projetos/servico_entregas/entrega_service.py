# Arquivo: servico_entregas/entrega_service.py
import json
# Importações necessárias. Presume-se que LogisticaGateway foi importado no api.py
from .logistica_gateway import ServiceUnavailableError

# Simulação de um repositório para persistir os dados (CRITÉRIO: DADOS PERSISTIDOS)
class EntregaRepository:
    """Simula a persistência de dados no banco (Histórico de Consultas)."""
    def salvar_consulta(self, tipo: str, dados: dict) -> dict:
        # CORREÇÃO CRÍTICA: Converte o dicionário em string JSON (imutável)
        # antes de calcular o hash, para evitar o TypeError.
        dados_str = json.dumps(dados, sort_keys=True)
        
        print(f"\n[DB] Persistindo consulta de {tipo}...")
        print(f"[DB] Dados Salvos: {dados}")
        
        return {"id_consulta": hash(dados_str), "status": "OK"}

# Serviço Principal (CRITÉRIO: QUALIDADE DE CÓDIGO E INJEÇÃO DE DEPENDÊNCIA)
class EntregaService:
    def __init__(self, logistica_gateway, repository: EntregaRepository):
        self.gateway = logistica_gateway
        self.repository = repository

    def solicitar_frete(self, dados_frete: dict) -> dict:
        # 1. Chamar a API via Gateway (o Gateway trata o Retry e retorna um dicionário)
        resultado = self.gateway.calcular_frete(dados_frete)
        
        # 2. Gerenciar a resposta/falha
        if "erro" in resultado:
            return {"status": "ERRO", "mensagem": f"Falha no cálculo do frete: {resultado.get('erro')}"}
        
        # 3. Persistir o histórico
        # O operador '|' combina os dicionários (Python 3.9+)
        self.repository.salvar_consulta("frete", dados_frete | resultado)
        
        return {"status": "SUCESSO", "detalhes": resultado}

    def consultar_rastreio(self, codigo: str) -> dict:
        try:
            resultado = self.gateway.rastrear_encomenda(codigo)
            
            # 1. Gerenciar a resposta/falha (O Gateway retorna um dicionário de erro se 4xx/5xx)
            if "erro" in resultado:
                return {"status": "ERRO", "mensagem": f"Falha no rastreio: {resultado.get('erro')}"}

            # 2. Persistir o histórico (Sucesso)
            self.repository.salvar_consulta("rastreio", {"codigo": codigo, "resultado": resultado})
            return {"status": "SUCESSO", "detalhes": resultado}
            
        except ServiceUnavailableError:
            # Captura a exceção re-lançada pelo Tenacity (após 3 tentativas)
            return {"status": "FALHA_LOGISTICA", "mensagem": "O serviço de logística falhou após várias tentativas. Tente mais tarde."}
        
        except Exception as e:
            # Captura qualquer outra exceção que possa ter sido propagada (ex: erros de Requests)
            return {"status": "ERRO", "mensagem": f"Erro inesperado no rastreio: {e.__class__.__name__}"}