import requests
import pytest
import time
from servico_entregas.logistica_gateway import ServiceUnavailableError 

# URLs para a integração
BASE_URL_ENTREGAS = "http://localhost:5000/entregas"
MOCK_URL = "http://localhost:5001" 

# O Fixture de verificação de conexão foi removido para evitar falhas no setup.
# Assumimos que o usuário iniciou os serviços corretamente.

# =================================================================
# TESTES DE SUCESSO (API Consumida Corretamente)
# =================================================================
def test_solicitar_frete_sucesso():
    """Verifica o cálculo de frete com dados válidos (200 OK)."""
    dados = {
        "cep_origem": "12345678",
        "cep_destino": "87654321",
        "peso_kg": 2.0,
        "dimensoes": {"altura": 10, "largura": 20, "comprimento": 30}
    }
    response = requests.post(f"{BASE_URL_ENTREGAS}/frete", json=dados)

    assert response.status_code == 200
    assert "valor_frete" in response.json()
    assert response.json()["valor_frete"] == 45.90

def test_rastreio_sucesso():
    """Cenário de sucesso: Retorna 200 e histórico de rastreio."""
    codigo_valido = "BR123456789BR"
    response = requests.get(f"{BASE_URL_ENTREGAS}/rastreio/{codigo_valido}")
    
    assert response.status_code == 200
    assert response.json()["codigo"] == codigo_valido
    assert "historico" in response.json()

# =================================================================
# TESTES DE FALHA CONTROLADA (400 e 500)
# =================================================================
def test_solicitar_frete_falha_cep_invalido():
    """Simulação de ERRO 400 (Bad Request)."""
    dados = {"cep_origem": "00000000", "cep_destino": "87654321", "peso_kg": 2.0} 
    response = requests.post(f"{BASE_URL_ENTREGAS}/frete", json=dados)
    
    assert response.status_code == 400
    assert "CEP de origem inválido" in response.json().get("mensagem")

def test_solicitar_frete_falha_servico_interno():
    """Simulação de ERRO 500 (Internal Server Error) - Carga muito pesada."""
    dados = {"cep_origem": "12345678", "cep_destino": "87654321", "peso_kg": 60.0}
    response = requests.post(f"{BASE_URL_ENTREGAS}/frete", json=dados)

    assert response.status_code == 500
    assert "Falha interna do serviço" in response.json().get("mensagem")

# =================================================================
# TESTE DE MOCK DE FALHAS (Critério: Tolerância a Falhas e Mock de Falhas)
# =================================================================

def test_rastreio_falha_com_retry_esgotado():
    """
    Verifica se o Retry tenta 3 vezes (tempo de espera) e retorna 503 no final.
    """
    codigo_falha = "FALHA503" 
    tempo_inicial = time.time()
    
    response = requests.get(f"{BASE_URL_ENTREGAS}/rastreio/{codigo_falha}")
    
    tempo_decorrido = time.time() - tempo_inicial
    
    assert response.status_code == 503
    assert "falhou após várias tentativas" in response.json().get("mensagem")
    assert tempo_decorrido > 2 
