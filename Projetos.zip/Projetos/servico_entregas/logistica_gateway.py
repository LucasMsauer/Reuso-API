import requests
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
import json

# Exceção personalizada para o Retry (critério de Tolerância a Falhas)
class ServiceUnavailableError(Exception):
    """Erro para falhas temporárias do serviço externo (503)."""
    pass

class LogisticaGateway:
    # URL do seu Mock
    BASE_URL = "http://localhost:5001" 

    @retry(
        stop=stop_after_attempt(3), 
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type(ServiceUnavailableError),
        reraise=True # Re-lança a exceção após 3 tentativas falharem
    )
    def _fazer_requisicao(self, endpoint, method="GET", json_data=None):
        url = f"{self.BASE_URL}/{endpoint}"
        
        try:
            # 1. Faz a Requisição HTTP
            response = requests.request(method, url, json=json_data)

            # 2. TRATAMENTO DO 503 (Para Retry)
            if response.status_code == 503:
                # Dispara a exceção para que o @retry do Tenacity funcione.
                raise ServiceUnavailableError(f"Erro 503 do Mock: {response.text}")

            # 3. TRATAMENTO DE SUCESSO (200 OK)
            if response.status_code == 200:
                # Retorna o JSON de sucesso
                return response.json()
            
            # 4. TRATAMENTO DE ERROS FINAIS (4xx e 5xx que não são 503)
            if response.status_code >= 400:
                # Se for um erro final (4xx, 500), retorna o corpo do erro (JSON)
                # O EntregaService verificará a chave 'erro'.
                try:
                    return response.json()
                except json.JSONDecodeError:
                    return {"erro": f"Erro HTTP {response.status_code} com corpo não JSON."}
        
        except requests.exceptions.RequestException as e:
            # Captura erros de conexão/DNS/Timeout antes mesmo de se conectar
            # O EntregaService vai tratar isso como um status 'ERRO'.
            return {"erro": f"Falha de Conexão Geral: {e.__class__.__name__}"}
        
    def calcular_frete(self, dados_frete):
        return self._fazer_requisicao("frete/calcular", method="POST", json_data=dados_frete)

    def rastrear_encomenda(self, codigo):
        # A exceção ServiceUnavailableError será lançada aqui se o retry falhar
        return self._fazer_requisicao(f"rastreio/{codigo}")