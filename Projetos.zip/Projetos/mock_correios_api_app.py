from flask import Flask, request, jsonify

app = Flask(__name__)
PORT = 5001

# Dados Fictícios de Rastreamento
RASTREAMENTO_DATA = {
    "BR123456789BR": {
        "codigo": "BR123456789BR",
        "status_atual": "Objeto entregue ao destinatário",
        "historico": [
            {"data": "2025-10-25", "status": "Objeto postado"},
            {"data": "2025-11-01", "status": "Objeto entregue ao destinatário"}
        ]
    }
}

@app.route('/frete/calcular', methods=['POST'])
def calcular_frete():
    """Simula o cálculo de frete com cenários de falha para testes."""
    data = request.get_json()
    cep_origem = data.get('cep_origem')
    peso_kg = data.get('peso_kg')

    # CENÁRIO DE FALHA 400 (Bad Request)
    if cep_origem == "00000000":
        return jsonify({"erro": "CEP de origem inválido. Verifique o formato."}), 400

    # CENÁRIO DE FALHA 500 (Internal Server Error - Mock de falhas)
    if peso_kg and peso_kg > 50:
        print("MOCK: SIMULANDO FALHA 500: Excesso de peso!")
        return jsonify({"erro": "Falha interna do serviço de frete (carga muito pesada)."}), 500

    # CENÁRIO DE SUCESSO
    return jsonify({
        "servico": "SEDEX",
        "valor_frete": 45.90,
        "prazo_dias": 5,
        "codigo_servico": "04510"
    }), 200

@app.route('/rastreio/<codigo>', methods=['GET'])
def rastrear_encomenda(codigo):
    """Simula o rastreamento com cenários de falha para testes."""
    
    # CENÁRIO DE FALHA 503 (Service Unavailable) - PARA TESTAR RETRY
    if codigo == "FALHA503":
        print("MOCK: SIMULANDO FALHA 503 (Service Unavailable)!")
        return jsonify({"erro": "Serviço de rastreio indisponível temporariamente."}), 503
        
    encomenda = RASTREAMENTO_DATA.get(codigo)
    
    # CENÁRIO DE FALHA 404 (Not Found)
    if not encomenda:
        return jsonify({"erro": "Código de rastreamento não encontrado."}), 404

    # CENÁRIO DE SUCESSO
    return jsonify(encomenda), 200

if __name__ == '__main__':
    print(f"MockCorreiosAPI rodando em http://localhost:{PORT}")
    app.run(port=PORT, debug=True, use_reloader=False) # <--- CORRIGIDO
