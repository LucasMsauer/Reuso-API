# Arquivo: teste_manual.py
# Demonstração manual dos endpoints da API de Entregas (http://localhost:5000)

import requests
import json
import time

BASE_URL = "http://localhost:5000/entregas"

def run_test(name, method, endpoint, data=None):
    """Função genérica para executar e exibir o resultado do teste."""
    print("=" * 60)
    print(f"| Teste: {name}")
    print("=" * 60)
    
    start_time = time.time()
    
    try:
        if method == "POST":
            response = requests.post(f"{BASE_URL}/{endpoint}", json=data)
        else:
            response = requests.get(f"{BASE_URL}/{endpoint}")
        
        duration = time.time() - start_time
        
        print(f"Status: {response.status_code}")
        print(f"Tempo de Resposta: {duration:.2f}s")
        print("Corpo da Resposta (JSON):")
        
        try:
            print(json.dumps(response.json(), indent=4, ensure_ascii=False))
        except json.JSONDecodeError:
            print(response.text)
            
    except requests.exceptions.ConnectionError:
        print("ERRO DE CONEXÃO: Certifique-se de que os servidores (5000 e 5001) estão rodando.")
    print("-" * 60)

# ----------------------------------------------------------------
# TESTES DE DEMONSTRAÇÃO
# ----------------------------------------------------------------

# 1. Sucesso no Cálculo de Frete (Requisito 1 & Persistência)
frete_data = {
    "cep_origem": "12345678",
    "cep_destino": "87654321",
    "peso_kg": 2.0,
    "dimensoes": {"altura": 10, "largura": 20, "comprimento": 30}
}
run_test("1. Sucesso - Calcular Frete", "POST", "frete", frete_data)


# 2. Sucesso no Rastreamento (Requisito 2 & Persistência)
run_test("2. Sucesso - Rastrear Encomenda", "GET", "rastreio/BR123456789BR")


# 3. Falha de Negócio - 400 (Requisito: API Consumida)
falha_400_data = {"cep_origem": "00000000", "cep_destino": "87654321", "peso_kg": 2.0}
run_test("3. Falha de Negócio - 400 (CEP Inválido)", "POST", "frete", falha_400_data)


# 4. Falha de Serviço - 500 (Requisito: Mock de Falhas)
falha_500_data = {"cep_origem": "12345678", "cep_destino": "87654321", "peso_kg": 60.0}
run_test("4. Falha de Serviço - 500 (Excesso de Peso)", "POST", "frete", falha_500_data)


# 5. Falha com RETRY - 503 (Requisito: Tolerância a Falhas - Mais Importante)
# Este teste levará ~7-10 segundos para finalizar, comprovando o Retry.
run_test("5. Falha Crítica - 503 (Comprovação do Retry)", "GET", "rastreio/FALHA503")